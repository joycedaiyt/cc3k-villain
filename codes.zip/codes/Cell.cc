#include "Cell.h"

Cell::Cell(char type):
    type{ type } {}
