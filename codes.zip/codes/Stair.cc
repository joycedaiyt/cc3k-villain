#include "Stair.h"

Stair::Stair(int x, int y):
    x{ x }, y{ y } {}
