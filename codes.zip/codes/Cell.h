#ifndef CELL_H
#define CELL_H
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>
using namespace std;

class Cell {
    public:
    char type;
    Cell(char type);
};

#endif
